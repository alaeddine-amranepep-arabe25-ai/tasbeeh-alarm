'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { BarChart3, House, Settings } from 'lucide-react'

const items = [
  { href: '/', label: 'الرئيسية', icon: House },
  { href: '/statistics', label: 'الإحصائيات', icon: BarChart3 },
  { href: '/dashboard', label: 'الإعدادات', icon: Settings },
]

export function BottomNav() {
  const pathname = usePathname()

  return (
    <nav
      aria-label="التنقل الرئيسي"
      className="sticky bottom-0 z-10 mt-6 -mx-5 border-t border-border bg-background/80 px-5 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 backdrop-blur-2xl sm:-mx-6 sm:px-6"
    >
      <ul className="flex items-center justify-between gap-2">
        {items.map(({ href, label, icon: Icon }) => {
          const active = pathname === href
          return (
            <li key={href} className="flex-1">
              <Link
                href={href}
                aria-current={active ? 'page' : undefined}
                className={`flex flex-col items-center gap-1.5 rounded-2xl py-2 text-[0.7rem] transition-colors ${
                  active
                    ? 'text-primary'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon className="size-5" aria-hidden />
                {label}
                <span
                  aria-hidden
                  className={`h-1 w-1 rounded-full transition-opacity ${
                    active ? 'bg-primary opacity-100' : 'opacity-0'
                  }`}
                />
              </Link>
            </li>
          )
        })}
      </ul>
    </nav>
  )
}

'use client'

import { Info } from 'lucide-react'
import { useEffect, useId, useState } from 'react'

type InfoTooltipProps = {
  text: string
  label: string
}

export function InfoTooltip({ text, label }: InfoTooltipProps) {
  const [open, setOpen] = useState(false)
  const id = useId()

  // tap-driven on mobile: close on outside tap or Escape
  useEffect(() => {
    if (!open) return
    const close = () => setOpen(false)
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false)
    }
    window.addEventListener('pointerdown', close)
    window.addEventListener('keydown', onKey)
    return () => {
      window.removeEventListener('pointerdown', close)
      window.removeEventListener('keydown', onKey)
    }
  }, [open])

  return (
    <span className="relative inline-flex">
      <button
        type="button"
        aria-label={label}
        aria-expanded={open}
        aria-describedby={open ? id : undefined}
        onPointerDown={(e) => e.stopPropagation()}
        onClick={() => setOpen((v) => !v)}
        className={`grid size-5 place-items-center rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
          open ? 'text-primary' : 'text-muted-foreground hover:text-primary'
        }`}
      >
        <Info className="size-3.5" aria-hidden />
      </button>

      {open ? (
        <span
          id={id}
          role="tooltip"
          className="absolute bottom-full right-0 z-30 mb-2 w-56 rounded-xl border border-border bg-popover px-3 py-2.5 text-[0.7rem] leading-relaxed text-popover-foreground shadow-[0_16px_40px_-16px_rgb(0_0_0/0.9)] text-pretty"
        >
          {text}
        </span>
      ) : null}
    </span>
  )
}

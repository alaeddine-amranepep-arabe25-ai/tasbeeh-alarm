'use client'

type ToggleSwitchProps = {
  checked: boolean
  onChange: (value: boolean) => void
  label: string
  size?: 'sm' | 'md'
}

export function ToggleSwitch({
  checked,
  onChange,
  label,
  size = 'md',
}: ToggleSwitchProps) {
  const track = size === 'sm' ? 'h-6 w-11' : 'h-7 w-[3.25rem]'
  const knob = size === 'sm' ? 'size-4' : 'size-5'
  const offset = size === 'sm' ? '-translate-x-5' : '-translate-x-6'

  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={`relative shrink-0 rounded-full border transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background ${track} ${
        checked
          ? 'border-primary/60 bg-primary shadow-[0_0_20px_-4px_rgb(16_185_129/0.8)]'
          : 'border-border bg-secondary'
      }`}
    >
      <span
        aria-hidden
        className={`absolute right-1 top-1/2 -translate-y-1/2 rounded-full transition-transform duration-200 ${knob} ${
          checked ? `${offset} bg-primary-foreground` : 'bg-muted-foreground'
        }`}
      />
    </button>
  )
}

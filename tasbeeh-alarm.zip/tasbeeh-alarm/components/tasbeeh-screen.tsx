'use client'

import { AlarmClock, BellOff, Check, ShieldAlert } from 'lucide-react'
import { useState } from 'react'
import { BottomNav } from '@/components/bottom-nav'
import { EmergencyOverride } from '@/components/emergency-override'
import { ProgressRing } from '@/components/progress-ring'
import { VoiceModeRow } from '@/components/voice-mode-row'

const TARGET = 10
const FAJR_TIME = '04:30 AM'

export function TasbeehScreen() {
  const [count, setCount] = useState(3)
  const [voiceMode, setVoiceMode] = useState(false)
  const [emergencyOpen, setEmergencyOpen] = useState(false)
  const [overridden, setOverridden] = useState(false)
  const remaining = Math.max(TARGET - count, 0)
  const dismissed = remaining === 0 || overridden

  return (
    <main className="relative mx-auto flex min-h-dvh w-full max-w-md flex-col overflow-hidden px-5 pb-8 pt-6 sm:px-6">
      {/* ambient dawn light, anchored behind the counter */}
      <div
        aria-hidden
        className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-primary/10 blur-[90px]"
      />

      <header className="relative flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 rounded-full border border-border bg-card px-3.5 py-2 backdrop-blur-xl">
          <AlarmClock
            className={`size-4 ${dismissed ? 'text-muted-foreground' : 'text-primary'}`}
            aria-hidden
          />
          <span
            dir="ltr"
            className="text-sm font-medium tabular-nums text-foreground"
          >
            {FAJR_TIME}
          </span>
          <span className="sr-only">وقت أذان الفجر</span>
          <span className="text-[0.7rem] text-muted-foreground">الفجر</span>
        </div>

        <p className="text-sm text-muted-foreground">صباح الخير</p>
      </header>

      <section className="relative mt-8 flex flex-1 flex-col items-center justify-center gap-8">
        {/* frosted glass dhikr card */}
        <div className="w-full rounded-3xl border border-border bg-card p-6 text-center shadow-[0_20px_60px_-30px_rgb(0_0_0/0.8)] backdrop-blur-2xl sm:p-8">
          <p className="text-[0.7rem] tracking-[0.3em] text-muted-foreground">
            ذكر الصباح
          </p>
          <p className="mt-5 font-serif text-3xl leading-relaxed text-foreground text-balance sm:text-4xl">
            أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ
          </p>
          <div
            aria-hidden
            className="mx-auto mt-6 h-px w-16 bg-gradient-to-l from-transparent via-primary/60 to-transparent"
          />
        </div>

        <div className="flex flex-col items-center gap-4">
          <ProgressRing count={Math.min(count, TARGET)} target={TARGET} />

          {/* discrete emergency escape hatch */}
          {dismissed ? null : (
            <button
              type="button"
              onClick={() => setEmergencyOpen(true)}
              className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.75rem] text-muted-foreground underline decoration-dotted decoration-1 underline-offset-4 transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <ShieldAlert className="size-3.5" aria-hidden />
              خيار الطوارئ
            </button>
          )}
        </div>
      </section>

      <footer className="relative mt-8 flex flex-col items-stretch gap-4">
        <VoiceModeRow
          checked={voiceMode}
          onChange={setVoiceMode}
          hint={
            voiceMode
              ? 'يستمع الآن، سبّح بصوتك ليُحتسب تلقائيًا'
              : 'شغّله لتُحتسب تسبيحاتك بصوتك دون لمس'
          }
        />

        <button
          type="button"
          onClick={() => setCount((c) => Math.min(c + 1, TARGET))}
          disabled={dismissed}
          className="group relative w-full overflow-hidden rounded-[2rem] bg-primary px-6 py-6 text-primary-foreground shadow-[0_0_50px_-8px_rgb(16_185_129/0.7)] transition-all duration-200 hover:brightness-110 active:scale-[0.97] active:shadow-[0_0_30px_-10px_rgb(16_185_129/0.6)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-default disabled:bg-secondary disabled:text-foreground disabled:shadow-none"
        >
          <span className="flex items-center justify-center gap-2.5 text-xl font-semibold">
            {dismissed ? (
              <>
                <Check className="size-5" aria-hidden />
                تم إيقاف المنبه
              </>
            ) : voiceMode ? (
              'سبّح بصوتك أو اضغط'
            ) : (
              'اضغط للتسبيح'
            )}
          </span>
        </button>

        <p className="flex items-center justify-center gap-2 text-center text-sm text-muted-foreground text-pretty">
          {overridden ? (
            <>
              <ShieldAlert className="size-4 text-primary" aria-hidden />
              تم الإيقاف عبر الوضع الطارئ
            </>
          ) : dismissed ? (
            <>
              <BellOff className="size-4 text-primary" aria-hidden />
              أكملت التسبيح، نمْ مطمئنًا أو ابدأ يومك
            </>
          ) : (
            <>بقي {remaining} تسبيحات لإيقاف المنبه</>
          )}
        </p>
      </footer>

      <EmergencyOverride
        open={emergencyOpen}
        onClose={() => setEmergencyOpen(false)}
        onUnlock={() => {
          setOverridden(true)
          setEmergencyOpen(false)
        }}
      />

      <BottomNav />
    </main>
  )
}

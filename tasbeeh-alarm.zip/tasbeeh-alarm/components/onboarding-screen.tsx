'use client'

import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { ArrowLeft, Moon } from 'lucide-react'

export function OnboardingScreen() {
  const router = useRouter()
  const [name, setName] = useState('')

  function handleStart(e: React.FormEvent) {
    e.preventDefault()
    router.push('/dashboard')
  }

  return (
    <div className="relative mx-auto flex min-h-dvh w-full max-w-md flex-col justify-between overflow-hidden px-6 pb-10 pt-16">
      <div
        aria-hidden
        className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-primary/12 blur-[100px]"
      />

      <main className="relative flex flex-1 flex-col items-center justify-center gap-10">
        {/* glowing crescent mark */}
        <div className="relative grid size-32 place-items-center">
          <span
            aria-hidden
            className="absolute inset-0 rounded-full bg-primary/15 blur-2xl"
          />
          <span
            aria-hidden
            className="absolute inset-0 rounded-full border border-primary/25"
          />
          <span
            aria-hidden
            className="absolute inset-4 rounded-full border border-primary/40"
          />
          <span className="relative grid size-16 place-items-center rounded-full bg-primary/15 shadow-[0_0_50px_-8px_rgb(16_185_129/0.85)]">
            <Moon
              className="size-8 text-primary"
              strokeWidth={1.75}
              aria-hidden
            />
            <span className="sr-only">رفيق الذكر</span>
          </span>
        </div>

        <div className="flex flex-col items-center gap-3 text-center">
          <h1 className="font-serif text-3xl leading-snug text-balance sm:text-4xl">
            أهلاً بك في رفيق الذكر
          </h1>
          <p className="max-w-xs text-sm leading-relaxed text-muted-foreground text-pretty">
            ابدأ يومك بطاعة الله واجعل لسانك رطباً بذكر الله
          </p>
        </div>
      </main>

      <form
        onSubmit={handleStart}
        className="relative flex flex-col items-center gap-5"
      >
        <div className="w-full">
          <label htmlFor="user-name" className="sr-only">
            الاسم
          </label>
          <input
            id="user-name"
            name="name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoComplete="name"
            placeholder="أدخل اسمك الكريم هنا..."
            className="h-14 w-full rounded-2xl border border-border bg-card px-5 text-center text-base text-foreground backdrop-blur-xl transition-colors placeholder:text-muted-foreground focus-visible:border-primary/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60"
          />
        </div>

        <button
          type="submit"
          className="group flex h-16 w-full items-center justify-center gap-3 rounded-2xl bg-primary text-base font-semibold text-primary-foreground shadow-[0_0_50px_-10px_rgb(16_185_129/0.95)] transition-transform duration-150 hover:brightness-110 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        >
          ابدأ الرحلة
          <ArrowLeft
            className="size-5 transition-transform duration-200 group-hover:-translate-x-1"
            aria-hidden
          />
        </button>

        <p className="text-[0.7rem] text-muted-foreground">
          يمكنك تعديل الإعدادات في أي وقت
        </p>
      </form>
    </div>
  )
}

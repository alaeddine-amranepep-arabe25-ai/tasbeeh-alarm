'use client'

import { Fingerprint, ShieldAlert, X } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'

const PASSCODE_LENGTH = 4

type EmergencyOverrideProps = {
  open: boolean
  onClose: () => void
  onUnlock: () => void
}

export function EmergencyOverride({
  open,
  onClose,
  onUnlock,
}: EmergencyOverrideProps) {
  const [code, setCode] = useState('')
  const [scanning, setScanning] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (open) {
      setCode('')
      setScanning(false)
      inputRef.current?.focus()
    }
  }, [open])

  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])

  if (!open) return null

  const handleCode = (value: string) => {
    const digits = value.replace(/\D/g, '').slice(0, PASSCODE_LENGTH)
    setCode(digits)
    if (digits.length === PASSCODE_LENGTH) {
      window.setTimeout(onUnlock, 250)
    }
  }

  const handleScan = () => {
    setScanning(true)
    window.setTimeout(onUnlock, 900)
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="emergency-title"
      className="fixed inset-0 z-50 flex items-end justify-center bg-background/80 px-4 pb-6 backdrop-blur-md sm:items-center sm:pb-0"
    >
      <button
        type="button"
        aria-label="إغلاق"
        onClick={onClose}
        className="absolute inset-0 cursor-default"
      />

      <div className="relative w-full max-w-sm rounded-3xl border border-border bg-card p-6 shadow-[0_30px_80px_-30px_rgb(0_0_0/0.9)]">
        <button
          type="button"
          onClick={onClose}
          aria-label="إلغاء الوضع الطارئ"
          className="absolute left-4 top-4 grid size-8 place-items-center rounded-full border border-border text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <X className="size-4" aria-hidden />
        </button>

        <div className="flex flex-col items-center text-center">
          <span className="grid size-11 place-items-center rounded-2xl bg-secondary">
            <ShieldAlert className="size-5 text-primary" aria-hidden />
          </span>
          <h2 id="emergency-title" className="mt-4 text-base font-semibold">
            الوضع الطارئ
          </h2>
          <p className="mt-2 text-[0.8rem] leading-relaxed text-muted-foreground text-pretty">
            أدخل رمز المرور أو استخدم بصمتك لإيقاف المنبه دون إكمال التسبيح
          </p>
        </div>

        <div className="mt-6">
          <label htmlFor="emergency-code" className="sr-only">
            رمز المرور
          </label>
          <input
            ref={inputRef}
            id="emergency-code"
            type="password"
            inputMode="numeric"
            autoComplete="off"
            value={code}
            onChange={(e) => handleCode(e.target.value)}
            className="sr-only"
          />
          <button
            type="button"
            onClick={() => inputRef.current?.focus()}
            dir="ltr"
            aria-hidden
            className="flex w-full items-center justify-center gap-3"
          >
            {Array.from({ length: PASSCODE_LENGTH }).map((_, i) => (
              <span
                key={i}
                className={`size-3.5 rounded-full transition-all duration-200 ${
                  i < code.length
                    ? 'bg-primary shadow-[0_0_14px_-2px_rgb(16_185_129/0.9)]'
                    : 'bg-secondary'
                }`}
              />
            ))}
          </button>
        </div>

        <div
          aria-hidden
          className="mx-auto mt-6 h-px w-24 bg-gradient-to-l from-transparent via-border to-transparent"
        />

        <button
          type="button"
          onClick={handleScan}
          className="mt-6 flex w-full items-center justify-center gap-2.5 rounded-2xl border border-primary/40 bg-primary/10 px-4 py-3.5 text-sm font-medium text-primary transition-all duration-200 hover:bg-primary/15 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        >
          <Fingerprint
            className={`size-5 ${scanning ? 'animate-pulse' : ''}`}
            aria-hidden
          />
          {scanning ? 'جارٍ التحقق من البصمة...' : 'استخدام البصمة'}
        </button>

        <p className="mt-4 text-center text-[0.7rem] text-muted-foreground text-pretty">
          يُسجَّل استخدام الوضع الطارئ في إحصائياتك
        </p>
      </div>
    </div>
  )
}

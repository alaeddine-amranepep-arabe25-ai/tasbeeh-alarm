'use client'

import Image from 'next/image'
import { useState } from 'react'
import { AlarmClock, Flame, Lock, Sparkles, Sunrise, Wand2 } from 'lucide-react'
import { BottomNav } from '@/components/bottom-nav'
import { InfoTooltip } from '@/components/info-tooltip'
import { ToggleSwitch } from '@/components/toggle-switch'
import { VoiceModeRow } from '@/components/voice-mode-row'

const COUNT_STEPS = [10, 20, 50]

const DHIKR_LIST = [
  { id: 'istighfar', text: 'أَسْتَغْفِرُ اللَّهَ', note: 'استغفار' },
  { id: 'tasbeeh', text: 'سُبْحَانَ اللَّهِ', note: 'تسبيح' },
  { id: 'salah', text: 'الصَّلاةُ عَلَى النَّبِيّ', note: 'صلاة' },
  { id: 'tahleel', text: 'لَا إِلَهَ إِلَّا اللَّهُ', note: 'تهليل' },
]

// ذكر اليوم: الجمعة للصلاة على النبي، وبقية الأيام تدور على القائمة
const DHIKR_BY_WEEKDAY = [
  'istighfar', // الأحد
  'tasbeeh', // الاثنين
  'tahleel', // الثلاثاء
  'istighfar', // الأربعاء
  'tasbeeh', // الخميس
  'salah', // الجمعة
  'tahleel', // السبت
]

const WEEKDAY_NAMES = [
  'الأحد',
  'الاثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
  'السبت',
]

const DAILY_TARGET = 200
const DAILY_DONE = 120

export function DashboardScreen() {
  const [lockPhone, setLockPhone] = useState(true)
  const [alarmOn, setAlarmOn] = useState(true)
  const [fajrTime, setFajrTime] = useState('04:30')
  const [stepIndex, setStepIndex] = useState(0)
  const [voiceMode, setVoiceMode] = useState(false)
  const [smartProgression, setSmartProgression] = useState(true)
  const [autoRotate, setAutoRotate] = useState(true)
  const [manualDhikr, setManualDhikr] = useState('istighfar')

  const weekday = new Date().getDay()
  const dhikrOfDay = DHIKR_BY_WEEKDAY[weekday]
  const activeDhikr = autoRotate ? dhikrOfDay : manualDhikr

  const requiredCount = COUNT_STEPS[stepIndex]
  const dailyPercent = Math.round((DAILY_DONE / DAILY_TARGET) * 100)

  return (
    <div className="relative mx-auto flex min-h-dvh w-full max-w-md flex-col px-5 pt-6 sm:px-6">
      <div
        aria-hidden
        className="pointer-events-none absolute -top-28 left-1/2 h-64 w-64 -translate-x-1/2 rounded-full bg-primary/10 blur-[90px]"
      />

      <header className="relative flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Image
            src="/images/avatar.png"
            alt="الصورة الشخصية"
            width={44}
            height={44}
            className="size-11 rounded-full border border-border object-cover"
          />
          <div className="flex flex-col gap-1">
            <p className="text-sm font-medium leading-none">أهلاً، عبد الله</p>
            <p className="flex items-center gap-1.5 text-[0.7rem] text-primary">
              <Flame className="size-3.5" aria-hidden />
              <span className="tabular-nums">5</span> أيام متتالية
            </p>
          </div>
        </div>
      </header>

      <main className="relative flex flex-1 flex-col gap-4 pt-6">
        {/* lock phone toggle */}
        <section className="flex items-center justify-between gap-4 rounded-2xl border border-border bg-card p-4 backdrop-blur-xl">
          <div className="flex items-center gap-3">
            <span className="grid size-9 place-items-center rounded-xl bg-secondary">
              <Lock className="size-4 text-primary" aria-hidden />
            </span>
            <div className="flex flex-col gap-1">
              <p className="text-sm font-medium leading-none">
                قفل الهاتف بالتسبيح
              </p>
              <p className="text-[0.7rem] text-muted-foreground">
                {lockPhone ? 'مُفعّل الآن' : 'غير مُفعّل'}
              </p>
            </div>
          </div>
          <ToggleSwitch
            checked={lockPhone}
            onChange={setLockPhone}
            label="قفل الهاتف بالتسبيح"
            size="sm"
          />
        </section>

        {/* fajr alarm settings */}
        <section className="rounded-3xl border border-border bg-card p-5 backdrop-blur-xl">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-2.5">
              <AlarmClock className="size-4 text-primary" aria-hidden />
              <h2 className="text-sm font-medium">منبه الفجر</h2>
            </div>
            <ToggleSwitch
              checked={alarmOn}
              onChange={setAlarmOn}
              label="تشغيل منبه الفجر"
              size="sm"
            />
          </div>

          <div className="mt-5 flex items-center justify-between gap-4 rounded-2xl bg-secondary px-4 py-3">
            <label
              htmlFor="fajr-time"
              className="text-[0.75rem] text-muted-foreground"
            >
              وقت المنبه
            </label>
            <input
              id="fajr-time"
              type="time"
              value={fajrTime}
              onChange={(e) => setFajrTime(e.target.value)}
              dir="ltr"
              className="bg-transparent text-2xl font-semibold tabular-nums text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-md"
            />
          </div>

          <div className="mt-5">
            <div className="flex items-center justify-between gap-3">
              <label
                htmlFor="required-count"
                className="text-[0.75rem] text-muted-foreground"
              >
                عدد التسبيحات لإيقاف المنبه
              </label>
              <span className="text-sm font-semibold tabular-nums text-primary">
                {requiredCount}
              </span>
            </div>
            <input
              id="required-count"
              type="range"
              min={0}
              max={COUNT_STEPS.length - 1}
              step={1}
              value={stepIndex}
              onChange={(e) => setStepIndex(Number(e.target.value))}
              aria-valuetext={`${requiredCount} تسبيحة`}
              className="mt-4 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-secondary accent-primary [&::-webkit-slider-thumb]:size-5 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-primary [&::-webkit-slider-thumb]:shadow-[0_0_16px_-2px_rgb(16_185_129/0.9)]"
            />
            <div className="mt-2 flex justify-between text-[0.7rem] tabular-nums text-muted-foreground">
              {COUNT_STEPS.map((value) => (
                <span key={value}>{value}</span>
              ))}
            </div>
          </div>

          {/* smart progression */}
          <div className="mt-5 flex items-center justify-between gap-4 border-t border-border pt-4">
            <div className="flex items-center gap-3">
              <span className="grid size-9 place-items-center rounded-xl bg-secondary">
                <Wand2 className="size-4 text-primary" aria-hidden />
              </span>
              <div className="flex flex-col gap-1">
                <span className="flex items-center gap-1.5">
                  <p className="text-sm font-medium leading-none">
                    التكيف الذكي
                  </p>
                  <InfoTooltip
                    label="شرح التكيف الذكي"
                    text="زيادة عدد التسبيحات تلقائياً بمرور الأيام لتثبيت العادة"
                  />
                </span>
                <p className="text-[0.7rem] text-muted-foreground">
                  {smartProgression
                    ? `الأسبوع القادم: ${requiredCount + 5} تسبيحة`
                    : 'العدد ثابت كما اخترته'}
                </p>
              </div>
            </div>
            <ToggleSwitch
              checked={smartProgression}
              onChange={setSmartProgression}
              label="التكيف الذكي"
              size="sm"
            />
          </div>
        </section>

        {/* voice tasbeeh mode */}
        <VoiceModeRow checked={voiceMode} onChange={setVoiceMode} />

        {/* dhikr selector */}
        <section>
          <div className="mb-3 flex items-center justify-between gap-3">
            <h2 className="text-sm font-medium">الذكر النشط</h2>
            <button
              type="button"
              onClick={() => {
                if (autoRotate) setManualDhikr(dhikrOfDay)
                setAutoRotate((v) => !v)
              }}
              aria-pressed={autoRotate}
              className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[0.7rem] transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                autoRotate
                  ? 'border-primary/50 bg-primary/10 text-primary'
                  : 'border-border bg-card text-muted-foreground hover:text-foreground'
              }`}
            >
              <Sparkles className="size-3.5" aria-hidden />
              أذكار متغيرة تلقائياً
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {DHIKR_LIST.map((dhikr) => {
              const active = dhikr.id === activeDhikr
              const isToday = dhikr.id === dhikrOfDay
              const showBadge = active && autoRotate && isToday
              return (
                <button
                  key={dhikr.id}
                  type="button"
                  onClick={() => {
                    setAutoRotate(false)
                    setManualDhikr(dhikr.id)
                  }}
                  aria-pressed={active}
                  className={`relative flex min-h-28 flex-col items-center justify-center gap-2 rounded-2xl border p-4 pt-6 text-center transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background ${
                    active
                      ? 'border-primary/60 bg-primary/15 shadow-[0_0_30px_-14px_rgb(16_185_129/0.9)]'
                      : 'border-border bg-card hover:border-input'
                  }`}
                >
                  {showBadge ? (
                    <span className="absolute right-2.5 top-2.5 flex items-center gap-1 rounded-full bg-primary px-2 py-0.5 text-[0.6rem] font-medium text-primary-foreground shadow-[0_0_16px_-4px_rgb(16_185_129/0.9)]">
                      <Sparkles className="size-2.5" aria-hidden />
                      تلقائي (ذكر اليوم)
                    </span>
                  ) : null}
                  <span
                    className={`font-serif text-lg leading-snug text-balance ${
                      active ? 'text-foreground' : 'text-secondary-foreground'
                    }`}
                  >
                    {dhikr.text}
                  </span>
                  <span
                    className={`text-[0.65rem] ${active ? 'text-primary' : 'text-muted-foreground'}`}
                  >
                    {dhikr.note}
                  </span>
                </button>
              )
            })}
          </div>

          <p className="mt-3 text-[0.7rem] text-muted-foreground text-pretty">
            {autoRotate
              ? `يتغيّر الذكر تلقائياً كل يوم — اليوم ${WEEKDAY_NAMES[weekday]}`
              : 'اخترت الذكر يدوياً، فعّل التغيير التلقائي لذكر كل يوم'}
          </p>
        </section>

        {/* daily progress */}
        <section className="rounded-3xl border border-border bg-card p-5 backdrop-blur-xl">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <Sunrise className="size-4 text-primary" aria-hidden />
              <h2 className="text-sm font-medium">تسبيحات اليوم</h2>
            </div>
            <p dir="ltr" className="text-sm font-semibold tabular-nums">
              <span className="text-primary">{DAILY_DONE}</span>
              <span className="text-muted-foreground"> / {DAILY_TARGET}</span>
            </p>
          </div>

          <div
            role="progressbar"
            aria-valuemin={0}
            aria-valuemax={DAILY_TARGET}
            aria-valuenow={DAILY_DONE}
            aria-label="تقدم تسبيحات اليوم"
            className="mt-4 h-2.5 w-full overflow-hidden rounded-full bg-secondary"
          >
            <div
              className="h-full rounded-full bg-primary shadow-[0_0_18px_-2px_rgb(16_185_129/0.9)] transition-[width] duration-500"
              style={{ width: `${dailyPercent}%` }}
            />
          </div>
          <p className="mt-3 text-[0.7rem] text-muted-foreground text-pretty">
            أكملت {dailyPercent}% من هدفك اليومي، بقي{' '}
            {DAILY_TARGET - DAILY_DONE} تسبيحة
          </p>
        </section>
      </main>

      <BottomNav />
    </div>
  )
}

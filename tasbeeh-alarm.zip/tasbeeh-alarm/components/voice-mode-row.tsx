'use client'

import { Mic, MicOff } from 'lucide-react'
import { ToggleSwitch } from '@/components/toggle-switch'

type VoiceModeRowProps = {
  checked: boolean
  onChange: (value: boolean) => void
  hint?: string
}

export function VoiceModeRow({ checked, onChange, hint }: VoiceModeRowProps) {
  const Icon = checked ? Mic : MicOff

  return (
    <div
      className={`flex items-center justify-between gap-4 rounded-2xl border p-4 backdrop-blur-xl transition-colors duration-200 ${
        checked ? 'border-primary/40 bg-primary/10' : 'border-border bg-card'
      }`}
    >
      <div className="flex items-center gap-3">
        <span
          className={`relative grid size-9 place-items-center rounded-xl ${
            checked ? 'bg-primary/20' : 'bg-secondary'
          }`}
        >
          <Icon
            className={`size-4 ${checked ? 'text-primary' : 'text-muted-foreground'}`}
            aria-hidden
          />
          {checked ? (
            <span
              aria-hidden
              className="absolute inset-0 animate-ping rounded-xl bg-primary/20"
            />
          ) : null}
        </span>
        <div className="flex flex-col gap-1">
          <p className="text-sm font-medium leading-none">
            التسبيح الصوتي (الميكروفون)
          </p>
          <p className="text-[0.7rem] text-muted-foreground text-pretty">
            {hint ?? (checked ? 'يستمع الآن، سبّح بصوتك' : 'العدّ باللمس فقط')}
          </p>
        </div>
      </div>
      <ToggleSwitch
        checked={checked}
        onChange={onChange}
        label="التسبيح الصوتي بالميكروفون"
        size="sm"
      />
    </div>
  )
}

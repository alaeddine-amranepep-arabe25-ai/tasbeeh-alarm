type ProgressRingProps = {
  count: number
  target: number
}

const RADIUS = 88
const CIRCUMFERENCE = 2 * Math.PI * RADIUS

export function ProgressRing({ count, target }: ProgressRingProps) {
  const ratio = Math.min(count / target, 1)
  const offset = CIRCUMFERENCE * (1 - ratio)
  const complete = count >= target

  return (
    <div
      className="relative aspect-square w-full max-w-[16rem]"
      role="progressbar"
      aria-valuemin={0}
      aria-valuemax={target}
      aria-valuenow={Math.min(count, target)}
      aria-label="عدد التسبيحات"
    >
      {/* soft halo behind the ring */}
      <div
        aria-hidden
        className="absolute inset-6 rounded-full bg-primary/15 blur-2xl transition-opacity duration-500"
        style={{ opacity: 0.35 + ratio * 0.65 }}
      />

      <svg viewBox="0 0 200 200" className="relative size-full -rotate-90">
        <circle
          cx="100"
          cy="100"
          r={RADIUS}
          fill="none"
          stroke="currentColor"
          className="text-border"
          strokeWidth="6"
        />
        <circle
          cx="100"
          cy="100"
          r={RADIUS}
          fill="none"
          stroke="currentColor"
          className="text-primary transition-[stroke-dashoffset] duration-700 ease-out"
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={CIRCUMFERENCE}
          strokeDashoffset={offset}
          style={{ filter: 'drop-shadow(0 0 10px rgb(16 185 129 / 0.7))' }}
        />
      </svg>

      <div className="absolute inset-0 flex flex-col items-center justify-center gap-1">
        <div
          dir="ltr"
          className="flex items-baseline gap-1 font-sans tabular-nums"
        >
          <span
            key={count}
            className="animate-in fade-in zoom-in-95 text-5xl font-semibold text-foreground duration-300"
          >
            {count}
          </span>
          <span className="text-2xl font-light text-muted-foreground">
            {'/'}
          </span>
          <span className="text-2xl font-light text-muted-foreground">
            {target}
          </span>
        </div>
        <span className="text-xs tracking-[0.2em] text-muted-foreground">
          {complete ? 'اكتمل الذكر' : 'تسبيحة'}
        </span>
      </div>
    </div>
  )
}

import { LocalNotifications } from '@capacitor/local-notifications'

export async function requestNotificationPermission() {
  const result = await LocalNotifications.requestPermissions()
  return result.display === 'granted'
}

export async function scheduleDailyAlarm(time: string) {
  const [hours, minutes] = time.split(':').map(Number)
  
  await LocalNotifications.schedule({
    notifications: [
      {
        title: "تذكير التسبيح",
        body: "حان وقت التسبيح والأذكار اليومية",
        id: 1,
        schedule: {
          on: {
            hour: hours,
            minute: minutes,
          },
          repeats: true,
        },
      },
    ],
  })
}

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface TasbeehState {
  count: number
  target: number
  totalCounts: number
  history: Record<string, number>
  increment: () => void
  reset: () => void
  setTarget: (target: number) => void
}

export const useTasbeehStore = create<TasbeehState>()(
  persist(
    (set) => ({
      count: 0,
      target: 33,
      totalCounts: 0,
      history: {},
      increment: () =>
        set((state) => {
          const today = new Date().toISOString().split('T')[0]
          const newCount = state.count + 1
          const newTotal = state.totalCounts + 1
          const currentDayCount = state.history[today] || 0
          
          return {
            count: newCount,
            totalCounts: newTotal,
            history: {
              ...state.history,
              [today]: currentDayCount + 1,
            },
          }
        }),
      reset: () => set({ count: 0 }),
      setTarget: (target) => set({ target }),
    }),
    {
      name: 'tasbeeh-storage',
    }
  )
)

import { BottomNav } from '@/components/bottom-nav'

const WEEK = [
  { day: 'السبت', value: 180 },
  { day: 'الأحد', value: 200 },
  { day: 'الاثنين', value: 140 },
  { day: 'الثلاثاء', value: 200 },
  { day: 'الأربعاء', value: 90 },
  { day: 'الخميس', value: 160 },
  { day: 'الجمعة', value: 120 },
]

const MAX = 200

export default function StatisticsPage() {
  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col px-5 pt-6 sm:px-6">
      <header className="flex flex-col gap-1">
        <h1 className="text-lg font-semibold">الإحصائيات</h1>
        <p className="text-sm text-muted-foreground">آخر سبعة أيام</p>
      </header>

      <main className="flex flex-1 flex-col gap-4 pt-6">
        <section className="rounded-3xl border border-border bg-card p-5 backdrop-blur-xl">
          <ul className="flex flex-col gap-3">
            {WEEK.map(({ day, value }) => (
              <li key={day} className="flex items-center gap-3">
                <span className="w-16 shrink-0 text-[0.7rem] text-muted-foreground">
                  {day}
                </span>
                <span className="h-2.5 flex-1 overflow-hidden rounded-full bg-secondary">
                  <span
                    className="block h-full rounded-full bg-primary"
                    style={{ width: `${(value / MAX) * 100}%` }}
                  />
                </span>
                <span className="w-8 shrink-0 text-left text-[0.7rem] tabular-nums text-foreground">
                  {value}
                </span>
              </li>
            ))}
          </ul>
        </section>

        <section className="grid grid-cols-2 gap-3">
          <div className="rounded-2xl border border-border bg-card p-4">
            <p className="text-[0.7rem] text-muted-foreground">أفضل سلسلة</p>
            <p className="mt-1 text-2xl font-semibold tabular-nums text-primary">
              12
            </p>
            <p className="text-[0.7rem] text-muted-foreground">يوم</p>
          </div>
          <div className="rounded-2xl border border-border bg-card p-4">
            <p className="text-[0.7rem] text-muted-foreground">
              إجمالي التسبيحات
            </p>
            <p className="mt-1 text-2xl font-semibold tabular-nums text-primary">
              1,090
            </p>
            <p className="text-[0.7rem] text-muted-foreground">هذا الأسبوع</p>
          </div>
        </section>
      </main>

      <BottomNav />
    </div>
  )
}

import { TasbeehScreen } from '@/components/tasbeeh-screen'

export default function Page() {
  return <TasbeehScreen />
}

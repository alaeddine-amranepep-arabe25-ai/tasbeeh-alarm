import { OnboardingScreen } from '@/components/onboarding-screen'

export default function WelcomePage() {
  return <OnboardingScreen />
}
